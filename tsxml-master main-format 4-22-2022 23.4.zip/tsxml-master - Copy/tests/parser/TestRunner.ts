import * as test from '../../src/test';						//This line doing parsing
import * as basicParsing from './basicParsing';				//This line doing parsing
import * as complexParsing from './complexParsing';			//This line doing parsing
import * as ambiguousParsing from './ambiguousParsing';		//This line doing parsing
import * as syntaxErrors from './syntaxErrors';				//This line doing parsing
import * as syntaxRules from './syntaxRules';				//This line doing parsing

@TestRunner.testName('Parser Tests')
export class TestRunner extends test.TestRunner {
	constructor() {
		super();
		this.add(
			new basicParsing.TestRunner(),
			new complexParsing.TestRunner(),
			new ambiguousParsing.TestRunner(),
			new syntaxErrors.TestRunner(),
			new syntaxRules.TestRunner()
		);
	}
}