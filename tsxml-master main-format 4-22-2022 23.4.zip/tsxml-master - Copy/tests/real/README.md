This directory contains test cases that cover working with real world examples (hence the directory name).

**Copyrights of all files in the 'xml' subdirectory remain with their original authors.**