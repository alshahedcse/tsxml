import './fileFormatter';               //This line doing parsing
import './simpleParsing';               //This line doing parsing
import './attributePropertyBinding';      //This line doing parsing