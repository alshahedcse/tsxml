import { Attribute } from './Attribute';

export type IAttribute<TValue> = TValue | Attribute<TValue>;
