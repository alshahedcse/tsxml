import { Node } from './Node';

export class SelfClosingNode extends Node { }
