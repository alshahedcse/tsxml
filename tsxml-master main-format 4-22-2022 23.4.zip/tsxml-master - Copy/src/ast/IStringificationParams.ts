export interface IStringificationParams {
	indentChar?: string;
	newlineChar?: string;
	attrParen?: string;
}
