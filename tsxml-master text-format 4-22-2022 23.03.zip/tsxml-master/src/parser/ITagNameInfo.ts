export interface ITagNameInfo {
	namespacePrefix?: string;
	tagName: string;
}
